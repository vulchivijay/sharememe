import React from 'react';
import { Route } from 'react-router-dom';

import AppTitle from './Components/AppTitle';
import PhotoWall from './Components/Photowall';
import AddPhoto from './Components/AddPhoto';

function SimulateFetchFromDataBase () {
  return [{
    id: Number(new Date()),
    description: "some description 1",
    imageWidth: 1000,
    imageHeight: 600,
    imageBColor: "#123456",
    imageFColor: "#ffffff",
    imageOverText: "Hello world"
  },
  {
    id: Number(new Date()),
    description: "some description 2",
    imageWidth: 1000,
    imageHeight: 600,
    imageBColor: "#123456",
    imageFColor: "#ffffff",
    imageOverText: "Hello world"
  },
  {
    id: Number(new Date()),
    description: "some description 3",
    imageWidth: 1000,
    imageHeight: 600,
    imageBColor: "#123456",
    imageFColor: "#ffffff",
    imageOverText: "Hello world"
  }]
}

class Main extends React.Component {
  constructor () {
    super();
    this.state = {
      posts: []
    }
    this.addPhoto = this.addPhoto.bind(this);
    this.removePhoto = this.removePhoto.bind(this);
    console.log("constructor!");
  }

  componentDidMount() {
    const BD_Data = SimulateFetchFromDataBase();
    this.setState({
      posts: BD_Data
    });
    console.log("component did mount!");
  }

  shouldComponentUpdate() {
    // true or false. by default true;
    // if false return render won't happen.
    console.log("should component update");
    return true;
  }

  addPhoto(postAdd) {
    this.setState( post => ({
      posts: this.state.posts.concat([postAdd])
    }));
    console.log(this.state);
  }

  removePhoto (postRemove) {
    this.setState( post => ({
      posts: this.state.posts.filter(post => post !== postRemove)
    }));
  }

  render () {
    console.log("render!");
    const appTitle = "PhotoWall";
    return (
      <div className="App">
        <AppTitle title={appTitle} />
        <Route exact path="/" render={() => {
          return <PhotoWall posts={this.state.posts} onRemovePhoto={this.removePhoto} />
        }} />
        <Route path="/AddPhotos" render={({history}) => {
          return <AddPhoto onAddPhoto={(addedPost) => {
            this.addPhoto(addedPost);
            history.push("/");
          }} />
        }} />
      </div>
    );
  }
}

export default Main;