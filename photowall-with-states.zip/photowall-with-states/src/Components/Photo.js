import React from 'react';
import PropTypes from 'prop-types';
import { CustomPlaceholder } from 'react-placeholder-image';

export default function Photo (props) {
    const post = props.post;
    return <figure className="photo-child">
      <CustomPlaceholder
        width={post.imageWidth}
        height={post.imageHeight}
        backgroundColor={post.imageBColor}
        textColor={post.imageFColor}
        text={post.imageOverText}
      />
      <figcaption>{post.description}</figcaption>
      <div className="btn-container">
        <button className="btn btn-danger" onClick={() => {
            props.onRemovePhoto(post)
          }}>Remove</button>
      </div>
    </figure>
}

Photo.propTypes = {
  // posts: PropTypes.object.isRequired,
  onRemovePhoto: PropTypes.func.isRequired
}