import React from 'react';

// Stateless component & function component
export default function AppTitle (props) {
  return (
    <div>
      <h1>{props.title}</h1>
    </div>
  )
}