import React from 'react';
import {Link} from 'react-router-dom';

class AddPhoto extends React.Component {

  constructor() {
    super();
    this.handleSubmit = this.handleSubmit.bind(this);
  }

  handleSubmit(event) {
    event.preventDefault();
    const Link = event.target.elements.link.value;
    const Description = event.target.elements.description.value;
    const Post = {
      id: Number(new Date()),
      description: Description,
      imageWidth: 1000,
      imageHeight: 600,
      imageBColor: "#123456",
      imageFColor: "#ffffff",
      imageOverText: "Hello world!!!"
    }
    if (Link && Description) {
      this.props.onAddPhoto(Post);
    }
  }

  render () {
    return (
      <div className="addPhoto-container">
        <Link to="/">Home</Link>
        <form className="addPhoto-form" onSubmit={this.handleSubmit}>
          <div>
            <label>Image URL:</label>
            <input type="text" placeholder="Link" name="link"/>
          </div>
          <div>
            <label>Image Description:</label>
            <textarea type="text" placeholder="Description" name="description"/>
          </div>
          <div className="btn-container">
            <button className="btn btn-green">Submit</button>
          </div>
        </form>
      </div>
    )
  }
}

export default AddPhoto;