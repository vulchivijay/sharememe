import React from 'react';
import PropTypes from 'prop-types';
import {Link} from 'react-router-dom';

import Photo from './Photo';

function PhotoWall(props) {
  return (
    <div>
      <Link to="/AddPhotos" className="btn-circle">+</Link>
      {/* <button className="btn-circle" onClick={props.addPhotosBtn}>+</button> */}
      <div className="photo-grid">
        {props.posts
          .sort((x, y) => {
            return y.id - x.id
          })
          .map((post, index) => {
            return <Photo
              key={index}
              post={post}
              onRemovePhoto={props.onRemovePhoto}
            />;
        })}
      </div>
    </div>
  );
}

PhotoWall.propTypes = {
  posts: PropTypes.array.isRequired,
  onRemovePhoto: PropTypes.func.isRequired
}

export default PhotoWall;