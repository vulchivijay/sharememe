import React from 'react';
// import PropTypes from 'prop-types';
import { CustomPlaceholder } from 'react-placeholder-image';
import {Link} from 'react-router-dom';

export default function Photo (props) {
    const post = props.post;
    return <figure className="photo-child">
      <Link to={`/single/${post.id}`}>
        <CustomPlaceholder
          width={post.imageWidth}
          height={post.imageHeight}
          backgroundColor={post.imageBColor}
          textColor={post.imageFColor}
          text={post.imageOverText}
        />
      </Link>
      <figcaption>{post.description}</figcaption>
      <div className="btn-container">
        <button className="btn btn-danger" onClick={() => {
            props.removePhoto(props.index)
            props.history.push("/")
          }}>Remove</button>
          <Link className="btn" to={`/single/${post.id}`}>
            <span>
              {props.comments[post.id] ? props.comments[post.id].length : 0}
            </span>
          </Link>
      </div>
    </figure>
}

// Photo.propTypes = {
//   posts: PropTypes.object.isRequired
// }