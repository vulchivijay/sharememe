import React from 'react';
import {Link} from 'react-router-dom';

// Stateless component & function component
export default function AppTitle (props) {
  return (
    <div>
      <h1>
        <Link to="/">{props.title}</Link>
      </h1>
    </div>
  )
}