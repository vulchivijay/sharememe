import React from 'react';
import PropTypes from 'prop-types';
import {Link} from 'react-router-dom';

import Photo from './Photo';

function PhotoWall(props) {
  // console.log(props);
  return (
    <div>
      <Link to="/AddPhotos" className="btn-circle">+</Link>
      <div className="photo-grid">
        {props.posts
          .sort((x, y) => {
            return y.id - x.id
          })
          .map((post, index) => {
            return <Photo
              key={index}
              post={post}
              {...props}
              index={index}
            />;
        })}
      </div>
    </div>
  );
}

PhotoWall.propTypes = {
  posts: PropTypes.array.isRequired
}

export default PhotoWall;