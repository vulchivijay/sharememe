import React from 'react';
import {Link} from 'react-router-dom';

const setBg = () => {
  const randomColor = Math.floor(Math.random()*16777215).toString(16);
  // document.body.style.backgroundColor = "#" + randomColor;
  return "#" + randomColor;
}

class AddPhoto extends React.Component {

  constructor() {
    super();
    this.handleSubmit = this.handleSubmit.bind(this);
  }

  generateBackround() {
    const randomColor = Math.floor(Math.random()*16777215).toString(16);
    return "#" + randomColor;
  }

  handleSubmit(event) {
    event.preventDefault();
    const Link = event.target.elements.link.value;
    const Description = event.target.elements.description.value;
    const Post = {
      id: Number(new Date()),
      description: Description,
      imageWidth: 1000,
      imageHeight: 600,
      imageBColor: setBg(),
      imageFColor: "#ffffff"
    }
    if (Link && Description) {
      this.props.addPhoto(Post);
      this.props.onHistory.push("/");
    }
  }

  render () {
    return (
      <div className="addPhoto-container">
        <Link to="/">Back</Link>
        <form className="addPhoto-form" onSubmit={this.handleSubmit}>
          <div>
            <label>Image URL:</label>
            <input type="text" placeholder="Link" name="link"/>
          </div>
          <div>
            <label>Image Description:</label>
            <textarea type="text" placeholder="Description" name="description"/>
          </div>
          <div className="btn-container">
            <button className="btn btn-green">Submit</button>
          </div>
        </form>
      </div>
    )
  }
}

export default AddPhoto;