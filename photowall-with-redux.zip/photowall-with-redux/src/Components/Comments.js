import React from 'react';

class Comments extends React.Component {

  constructor() {
    super();
    this.handleSubmit = this.handleSubmit.bind(this);
  }

  handleSubmit (event) {
    event.preventDefault();
    //console.log(event.target.elements.comments.value)
    const comment = event.target.elements.comments.value;
    this.props.addComment(comment, this.props.id);
    event.target.elements.comments.value = "";
  }

  render() {
    // console.log(this.props.comments);
    return (
      <div className="photo-child">
        <form className="comment-form" onSubmit={this.handleSubmit}>
          <div>
            <textarea type="text" placeholder="Comments" name="comments"/>
          </div>
          <div className="btn-container">
            <button className="btn btn-green">Submit</button>
          </div>
        </form>
      </div>
    );
  }
}

export default Comments;