const setBg = () => {
  const randomColor = Math.floor(Math.random()*16777215).toString(16);
  return "#" + randomColor;
}

const posts = [{
  id: 0,
  description: "some description 1",
  imageWidth: 1000,
  imageHeight: 600,
  imageBColor: setBg(),
  imageFColor: "#ffffff"
},
{
  id: 1,
  description: "some description 2",
  imageWidth: 1000,
  imageHeight: 600,
  imageBColor: setBg(),
  imageFColor: "#ffffff"
},
{
  id: 2,
  description: "some description 3",
  imageWidth: 1000,
  imageHeight: 600,
  imageBColor: setBg(),
  imageFColor: "#ffffff"
},
{
  id: 3,
  description: "some description 4",
  imageWidth: 1000,
  imageHeight: 600,
  imageBColor: setBg(),
  imageFColor: "#ffffff"
}]

export default posts;