// remove
export function removePhoto(index) {
  console.log("action", index);
  return {
    type: "REMOVE_PHOTO",
    index: index
  }
}

export function addPhoto(post) {
  return {
    type: "ADD_PHOTO",
    post: post
  }
}

export function addComment(comment, postid) {
  return {
    type: "ADD_COMMENT",
    comment: comment,
    postid: postid
  }
}