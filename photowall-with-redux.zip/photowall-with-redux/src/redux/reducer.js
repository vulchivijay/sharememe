import postsData from './../data/posts';
import { combineReducers } from 'redux';

const comments = function(state={}, action) {
  // console.log("Comment reducer");
  switch (action.type) {
    case "ADD_COMMENT":
      if (!state[action.postid])
        return {...state, [action.postid]: [action.comment] }
      else
        return {...state, [action.postid]: [...state[action.postid], action.comment] }
    default: return state;
  }
}

const posts = function (state = postsData, action) {
  // console.log("Post reducer");
  switch(action.type) {
    case "REMOVE_PHOTO": return [...state.slice(0, action.index), ...state.slice(action.index + 1)]
    case "ADD_PHOTO": return [...state, action.post]
    default: return state;

  }
}

const rootReducers = combineReducers({posts, comments})

export default rootReducers;