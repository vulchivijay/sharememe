import React from 'react';
import {Link} from 'react-router-dom';

// Stateless component & function component
export default function Header (props) {
  return (
    <header>
      <nav className="primary-nav">
        <Link className="title" to="/">
          <i className="fab fa-meetup"></i>
          {props.title}
        </Link>
        <Link className="btn-add" to="/AddPhotos">
          <i className="fas fa-plus-square"></i>
        </Link>
      </nav>
    </header>
  )
}