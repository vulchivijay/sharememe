import React from 'react';
import Photo from './Photo';
import Comments from './Comments'

class Single extends React.Component {

  render () {
    const {match, posts} = this.props;
    const id = Number(match.params.id);
    const post = posts.find((post) => post.id === id)
    const comments = this.props.comments[id] || [];
    const index = this.props.posts.findIndex((post) => post.id === id)
    // console.log(this.props.match);
    // console.log(comments);
    return (
      <div className="app-container singlePhoto">
        <Photo post={post} {...this.props} index={index} />
        <Comments startAddingComment={this.props.startAddingComment} id={id} comments={comments}/>
      </div>
    );
  } 
}

export default Single;
