import React from 'react';

class Comments extends React.Component {

  constructor() {
    super();
    this.handleSubmit = this.handleSubmit.bind(this);
  }

  handleSubmit (event) {
    event.preventDefault();
    //console.log(event.target.elements.comments.value)
    const comment = event.target.elements.comments.value;
    // this.props.addComment(comment, this.props.id); // without firebase
    this.props.startAddingComment(comment, this.props.id);
    event.target.elements.comments.value = "";
  }

  render() {
    // console.log(this.props.comments);
    return (
      <div className="comments-container">
        <div className="comments">
          <p>Comments: </p>
          <hr />
          {
            this.props.comments.map((comment, index) => {
              return <div>
                  <div className="comment-child" key={index}>{comment}</div>
                  <hr />
                </div>
            })
          }
        </div>
        <div className="photo-child">
          <form className="comment-form" onSubmit={this.handleSubmit}>
            <div>
              <input type="text" placeholder="Comments" name="comments"/>
            </div>
            <div className="btn-container">
              <button className="btn btn-green">Add comment</button>
            </div>
          </form>
        </div>
      </div>
    );
  }
}

export default Comments;