import React from 'react';
// import PropTypes from 'prop-types';
import {Link} from 'react-router-dom';

export default function Photo (props) {
    const post = props.post;
    return <figure className="photo-child">
      <Link to={`/single/${post.id}`}>
        <img src={process.env.PUBLIC_URL + post.imageUrl} alt={post.description} />
      </Link>
      <div className="action-element">
        <Link className="comments-count" to={`/single/${post.id}`}>
          <i className="fas fa-comment"></i>
          <span>
            {props.comments[post.id] ? props.comments[post.id].length : 0}
          </span>
        </Link>
        <button className="btn-delete" onClick={() => {
            // props.removePhoto(props.index) // without firebase
            props.removeAddedPhoto(props.index, post.id) // with firebase
            props.history.push("/")
        }}>
          <i className="fas fa-trash-alt">
        </i></button>
      </div>
      <figcaption>{post.description}</figcaption>
    </figure>
}

// Photo.propTypes = {
//   posts: PropTypes.object.isRequired
// }