const posts = [{
  id: Number(new Date()),
  description: "some description 1",
  imageWidth: 1000,
  imageHeight: 600,
  imageBColor: "#123456",
  imageFColor: "#ffffff",
  imageOverText: "Hello world"
},
{
  id: Number(new Date()),
  description: "some description 2",
  imageWidth: 1000,
  imageHeight: 600,
  imageBColor: "#123456",
  imageFColor: "#ffffff",
  imageOverText: "Hello world"
},
{
  id: Number(new Date()),
  description: "some description 3",
  imageWidth: 1000,
  imageHeight: 600,
  imageBColor: "#123456",
  imageFColor: "#ffffff",
  imageOverText: "Hello world"
}]

export default posts;