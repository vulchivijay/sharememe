import firebase from "firebase";

// Your web app's Firebase configuration
// var config = {
//   apiKey: "AIzaSyDAFM811Gt_Vq_6hTvCIiJSrVTdNx-wv64",
//   authDomain: "photowall-react-83a35.firebaseapp.com",
//   projectId: "photowall-react-83a35",
//   storageBucket: "photowall-react-83a35.appspot.com",
//   messagingSenderId: "175818602235",
//   appId: "1:175818602235:web:32a6c0925b1ee851cd225e"
// };

var config = {
  apiKey: "AIzaSyAe9IzG0x_BWLr2uKjm5pe2cOy4plEY9K4",
  authDomain: "meme-react-47a8f.firebaseapp.com",
  databaseURL: "https://meme-react-47a8f-default-rtdb.firebaseio.com",
  projectId: "meme-react-47a8f",
  storageBucket: "meme-react-47a8f.appspot.com",
  messagingSenderId: "106235102051",
  appId: "1:106235102051:web:4658affbdcc5132e464956"
};

firebase.initializeApp(config)

const database = firebase.database()

export {database}

