import {database} from './../database/config'

export function startAddingPhoto(post) {
  return (dispatch) => {
    return database.ref("posts").update({[post.id]: post}).then(() => {
      dispatch(addPhoto(post))
    }).catch(err => {
      console.log(err);
    });
  }
}

export function removeAddedPhoto(index, id) {
  return (dispatch) => {
    return database.ref(`posts/${id}`).remove().then(() => {
      dispatch(removePhoto(index));
    }).catch(err => {
      console.log(err);
    });
  }
}

export function loadingPhotos() {
  return (dispatch) => {
    return database.ref("posts").once('value').then((snapShot) => {
      let Posts = [];
      snapShot.forEach((childrenSnapShot) => {
        Posts.push(childrenSnapShot.val())
      });
      dispatch(loadPhotos(Posts))
    }).catch(err => {
      console.log(err);
    });
  }
}

export function startAddingComment(comment, postId) {
  return (dispatch) => {
    return database.ref(`comments/`+postId).push(comment).then(()=> {
      dispatch(addComment(comment, postId))
    }).catch(err => {
      console.log(err);
    });
  }
}

export function loadingComments() {
  return (dispatch) => {
    return database.ref("comments").once('value').then((snapShot) => {
      let Comments = {};
      snapShot.forEach((childrenSnapShot) => {
        Comments[childrenSnapShot.key] = Object.values(childrenSnapShot.val())
      });
      dispatch(loadComments(Comments))
    }).catch(err => {
      console.log(err);
    });
  }
}

export function loadPhotos(posts) {
  return {
    type: "LOAD_PHOTOS",
    posts: posts
  }
}

export function loadComments(comments) {
  return {
    type: "LOAD_COMMENTS",
    comments: comments
  }
}

// remove
export function removePhoto(index) {
  console.log("action", index);
  return {
    type: "REMOVE_PHOTO",
    index: index
  }
}

export function addPhoto(post) {
  return {
    type: "ADD_PHOTO",
    post: post
  }
}

export function addComment(comment, postid) {
  return {
    type: "ADD_COMMENT",
    comment: comment,
    postid: postid
  }
}