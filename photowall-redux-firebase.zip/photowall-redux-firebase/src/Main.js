import React from 'react';
import { Route } from 'react-router-dom';

import Header from './Components/header';
import PhotoWall from './Components/Photowall';
import AddPhoto from './Components/AddPhoto';
import Single from './Components/Single';

class Main extends React.Component {
  constructor () {
    super();
    console.log("constructor!");
  }

  render () {
    console.log("render!");
    // console.log(this.props); // globle store data and its methods
    const appTitle = "eme's";
    return (
      <div className="App">
        <Header title={appTitle} />
        <Route exact path="/" render={() => {
          return <PhotoWall {...this.props} />
        }} />
        <Route path="/AddPhotos" render={({history}) => {
          return <AddPhoto onHistory={history} {...this.props}/>
        }} />
        <Route path="/single/:id" render={(params) => {
          return <Single {...this.props} {...params}/>
        }} />
      </div>
    );
  }

  componentDidMount() {
    console.log("component did mount!");
    this.props.loadingPhotos();
    this.props.loadingComments();
  }
}

export default Main;